rootProject.name = "ProxBlocker"
include(":app")
